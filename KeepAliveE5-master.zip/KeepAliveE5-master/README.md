# Usage

Set the following repo secrets, then trigger `Register APP` workflow manually. Read [Intro](https://logi.im/script/permanently-keeping-an-office-e5-account.html) for more details.

| Name   | Value                                                   |
| ------ | ------------------------------------------------------- |
| PAT    | Github personal access token with `workflow` permission |
| USER   | E5 admin emails line separated                          |
| PASSWD | E5 admin passwords line separated                       |

<p align="right"><code>version@20221111</code></p>
